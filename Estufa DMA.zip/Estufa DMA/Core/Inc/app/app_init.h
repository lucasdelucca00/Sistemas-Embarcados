/*
 * app_init.h
 *
 *  Created on: Dec 17, 2025
 *      Author: Lukinhas
 */

#pragma once

void APP_Init(void);
