/*
 * app_tasks.h
 *
 *  Created on: Dec 17, 2025
 *      Author: Lukinhas
 */

#ifndef INC_APP_APP_TASKS_H_
#define INC_APP_APP_TASKS_H_

void APP_CreateTasks(void);


#endif /* INC_APP_APP_TASKS_H_ */
