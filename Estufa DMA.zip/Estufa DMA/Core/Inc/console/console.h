/*
 * console.h
 *
 *  Created on: Dec 17, 2025
 *      Author: Lukinhas
 */

#ifndef CONSOLE_H
#define CONSOLE_H

#include "FreeRTOS.h"
#include "task.h"
#include "FreeRTOS_IO.h"
#include <stdarg.h>

/* Inicializa o console (UART + CLI) */
void Console_Init(void);

/* Task principal do console */
void Console_Task(void *argument);

/* Print formatado seguro */
void Console_Printf(const char *fmt, ...);

/* Retorna se o console já está pronto */
BaseType_t Console_IsReady(void);

#endif /* CONSOLE_H */

