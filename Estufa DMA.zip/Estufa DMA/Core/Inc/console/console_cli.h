/*
 * console_cli.h
 *
 *  Created on: Dec 17, 2025
 *      Author: Lukinhas
 */

#ifndef CONSOLE_CLI_H
#define CONSOLE_CLI_H

void Console_CLI_RegisterCommands(void);

#endif /* CONSOLE_CLI_H */

