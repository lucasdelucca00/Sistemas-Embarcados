/*
 * fan_control.h
 *
 *  Created on: Dec 16, 2025
 *      Author: Lukinhas
 */

#ifndef FAN_CONTROL_H
#define FAN_CONTROL_H

#include <stdint.h>

typedef enum
{
    FAN_MODE_MANUAL = 0,
    FAN_MODE_AUTO
} fan_mode_t;

/* Init */
void FAN_CTRL_Init(void);

/* Mode */
void FAN_CTRL_SetMode(fan_mode_t mode);
fan_mode_t FAN_CTRL_GetMode(void);

/* Manual control */
void FAN_CTRL_SetManual(uint8_t pct);
uint8_t FAN_CTRL_GetManual(void);

/* Status */
uint8_t FAN_CTRL_GetCurrent(void);

/* Task */
void FAN_CTRL_Task(void *arg);

#endif



