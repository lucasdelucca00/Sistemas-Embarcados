/*
 * lamp_control.h
 *
 *  Created on: Dec 15, 2025
 *      Author: Lukinhas
 */

#ifndef LAMP_CONTROL_H
#define LAMP_CONTROL_H

#include <stdint.h>

typedef enum
{
    LAMP_MODE_OFF = 0,
    LAMP_MODE_ON,
    LAMP_MODE_WINDOW
} lamp_mode_t;

/* Init do módulo */
void LAMP_Init(void);

/* Controle direto */
void LAMP_On(void);
void LAMP_Off(void);

/* Controle por janela */
void LAMP_SetWindow(uint32_t on_ms, uint32_t off_ms);
void LAMP_GetWindow(uint32_t *on_ms, uint32_t *off_ms);
void LAMP_HW_On(void);
void LAMP_HW_Off(void);

/* Status */
lamp_mode_t LAMP_GetMode(void);
uint32_t    LAMP_GetOnTime(void);
uint32_t    LAMP_GetOffTime(void);

/* Task */
void LAMP_Task(void *arg);

#endif






