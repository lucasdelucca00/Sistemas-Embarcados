/*
 * fan_pwm.h
 *
 *  Created on: Dec 16, 2025
 *      Author: Lukinhas
 */

// fan_pwm.h
#ifndef FAN_PWM_H
#define FAN_PWM_H

#include <stdint.h>

void FAN_PWM_Init(void);
void FAN_SetPct(uint8_t pct);
uint8_t FAN_GetPct(void);

#endif

