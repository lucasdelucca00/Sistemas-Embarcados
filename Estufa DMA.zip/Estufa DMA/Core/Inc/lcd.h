/*
 * lcd.h
 *
 *  Created on: Dec 14, 2025
 *      Author: Lukinhas
 */
#ifndef LCD_H
#define LCD_H

#include "stm32g4xx_hal.h"
#include <stdint.h>

void LCD_Init(void);
void LCD_Clear(void);
void LCD_Home(void);
void LCD_SetCursor(uint8_t row, uint8_t col);
void LCD_WriteChar(char c);
void LCD_WriteString(const char *s);

#endif /* INC_LCD_H_ */
