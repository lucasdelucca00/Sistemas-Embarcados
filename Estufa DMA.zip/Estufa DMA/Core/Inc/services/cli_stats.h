/*
 * cli_stats.h
 *
 *  Created on: Dec 18, 2025
 *      Author: Lukinhas
 */

#ifndef CLI_STATS_H
#define CLI_STATS_H

#include "FreeRTOS.h"
#include "task.h"

/* Inicialização (mutexes, buffers, etc.) */
void CLI_StatsInit(void);

/* Task responsável por coletar stats */
void CLI_StatsTask(void *argument);

/* API para o CLI copiar dados prontos */
void CLI_CopyTaskList(char *dst, size_t len);
void CLI_CopyRuntime(char *dst, size_t len);

#endif /* CLI_STATS_H */
