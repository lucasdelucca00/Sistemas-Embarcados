/*
 * queue_temp.h
 *
 *  Created on: Dec 17, 2025
 *      Author: Lukinhas
 */

#pragma once
#include "FreeRTOS.h"
#include "queue.h"

extern QueueHandle_t qTemp;

void QUEUE_TempInit(void);
void QUEUE_TempPublish(float tempC);
BaseType_t QUEUE_TempGetLatest(float *out, TickType_t timeout);

