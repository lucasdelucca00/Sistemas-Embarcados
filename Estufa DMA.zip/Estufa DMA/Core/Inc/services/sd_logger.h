/*
 * sd_logger.h
 *
 *  Created on: Dec 18, 2025
 *      Author: Lukinhas
 */

#pragma once
#include "FreeRTOS.h"
#include "queue.h"

typedef enum {
    SD_CMD_WRITE,
    SD_CMD_READ
} sd_cmd_t;

void SD_LoggerInit(void);
QueueHandle_t SD_GetQueue(void);
void SD_Task(void *arg);


