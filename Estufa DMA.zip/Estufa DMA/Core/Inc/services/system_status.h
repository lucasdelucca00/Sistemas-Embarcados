/*
 * system_status.h
 *
 *  Created on: Dec 15, 2025
 *      Author: Lukinhas
 */

#pragma once
#include <stdint.h>

#define SYS_TEMP_HIST_N 10

typedef struct
{
    uint32_t uptime_ms;

    float temp_now_c;
    float temp_last[SYS_TEMP_HIST_N];
    uint8_t temp_n;
    uint8_t fan_pct;
    uint8_t lamp_pct;
    // --- FUTURO (deixe comentado por enquanto) ---
    // uint8_t fan_on;
    // uint8_t lamp_on;
    // float humidity_now;      // se colocar DHT/whatever
} system_status_t;

void SYS_StatusInit(void);
void SYSSTAT_Get(system_status_t *out);
void SYS_UpdateLm35Temp(float tempC);
void SYS_UpdateOutputs(uint8_t fan_pct, uint8_t lamp_pct);
void SYSSTAT_SetFanPct(uint8_t pct);
uint8_t SYSSTAT_GetFanPct(void);
uint8_t SYSSTAT_GetLampPct(void);
void SYSSTAT_SetTemperature(float tempC);
void SYSSTAT_SetLampPct(uint8_t pct);
