/*
 * thermal_control.h
 *
 *  Created on: Dec 18, 2025
 *      Author: Lukinhas
 */

#pragma once

#include <stdint.h>
#include "FreeRTOS.h"
#include "task.h"

typedef enum {
  THERM_IDLE = 0,
  THERM_HEAT_FULL,
  THERM_HEAT_WINDOW,
  THERM_COOL_STRONG,
  THERM_COOL_SOFT
} thermal_state_t;

typedef enum {
  THERM_MODE_MANUAL = 0,
  THERM_MODE_AUTO
} thermal_mode_t;

void THERM_SetMode(thermal_mode_t mode);
thermal_mode_t THERM_GetMode(void);
thermal_state_t THERM_GetState(void);
void THERM_Task(void *arg);
void THERM_Init(void);


