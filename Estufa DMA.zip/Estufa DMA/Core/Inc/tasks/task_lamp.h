/*
 * task_lamp.h
 *
 *  Created on: Dec 17, 2025
 *      Author: Lukinhas
 */

#pragma once
void LAMP_Task(void *argument);
