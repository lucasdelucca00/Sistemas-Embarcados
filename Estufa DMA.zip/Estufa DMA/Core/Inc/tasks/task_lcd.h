/*
 * task_lcd.h
 *
 *  Created on: Dec 17, 2025
 *      Author: Lukinhas
 */

#ifndef INC_TASKS_TASK_LCD_H_
#define INC_TASKS_TASK_LCD_H_

#include "FreeRTOS.h"
#include "task.h"

/* Protótipo da task */
void StartLcdTask(void *argument);

#endif /* INC_TASKS_TASK_LCD_H_ */

