/*
 * task_temp.h
 *
 *  Created on: Dec 17, 2025
 *      Author: Lukinhas
 */

#ifndef INC_TASKS_TASK_TEMP_H_
#define INC_TASKS_TASK_TEMP_H_


/* Task pública */
void LM35_Task(void *param);

/* Exibe no shell com comando 'temp' */
float LM35_GetTempC(void);

#endif /* INC_TASKS_TASK_TEMP_H_ */
