/*
 * tasks_console.h
 *
 *  Created on: Dec 17, 2025
 *      Author: Lukinhas
 */

#ifndef INC_TASKS_TASKS_CONSOLE_H_
#define INC_TASKS_TASKS_CONSOLE_H_



#endif /* INC_TASKS_TASKS_CONSOLE_H_ */
