/*
 * app_init.h
 *
 *  Created on: Dec 17, 2025
 *      Author: Lukinhas
 */

#include "app/app_init.h"
#include "app/app_tasks.h"
#include "control/fan_control.h"
#include "control/lamp_control.h"
#include "services/system_status.h"
#include "console/console.h"
#include "services/queue_temp.h"

void APP_Init(void)
{
    /* Serviços base */
    SYS_StatusInit();
    QUEUE_TempInit();
    /* Controles */
    FAN_CTRL_Init();
    LAMP_Init();

    /* Console */
    Console_Init();
}

