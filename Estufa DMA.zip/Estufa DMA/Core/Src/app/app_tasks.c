/*
 * app_tasks.c
 *
 *  Created on: Dec 17, 2025
 *      Author: Lukinhas
 */


#include "FreeRTOS.h"
#include "task.h"
#include "tasks/task_temp.h"
#include "services/thermal_control.h"
#include "services/sd_logger.h"

/* includes das tasks */
#include "app/app_tasks.h"
#include "tasks/task_lcd.h"
#include "console/console.h"
#include "control/fan_control.h"
#include "control/lamp_control.h"

void APP_CreateTasks(void)
{
	SD_LoggerInit();

	xTaskCreate(Console_Task,"Shell Terminal (CLI) ",1024,NULL,4,NULL);

    xTaskCreate(FAN_CTRL_Task,"Controle da Fan",256,NULL,2,NULL);

    xTaskCreate(LAMP_Task,"Controle da Lampada",224,NULL,2,NULL);

    xTaskCreate(LM35_Task,"Ler Temp ºC (LM35)",512,NULL,2,NULL);

    xTaskCreate(StartLcdTask,"Transmite LCD",512,NULL,2,NULL);

    xTaskCreate(THERM_Task, "Controle Automatico de Temperatura", 256, NULL, 3, NULL);

    xTaskCreate(SD_Task,"SD",2048,NULL,1,NULL);

    //xTaskCreate(SD_WriteTask, "SD Write", 4096, NULL, 1, NULL);

    //xTaskCreate(SD_ReadTask,  "SD Read",  4096, NULL,1 , NULL);

    //xTaskCreate(pisca_led, "Led - Verde", 256, &led_verde, 3, NULL);
    //xTaskCreate(envia_serial_1, "serial 1", 256, NULL, 3, NULL);
    //xTaskCreate(envia_serial_2, "serial 2", 256, NULL, 3, NULL);
    //xTaskCreate(shell_task, "Shell Terminal", 1024, NULL, 4, NULL);
    //xTaskCreate(sd_card_task, "Gravar no SD", 2048, NULL, 2, &g_sdTaskHandle);
    //xTaskCreate(sobra_cpu, "Sobra CPU", 256, NULL, 1, NULL);
    //xTaskCreate(temp_stream_task, "temp stream", 512, NULL, 2, NULL);
}

