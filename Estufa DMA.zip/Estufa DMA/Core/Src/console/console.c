/*
 * console.c
 *
 *  Created on: Dec 17, 2025
 *      Author: Lukinhas
 */

#include "console/console.h"
#include "console/console_cli.h"

#include "FreeRTOS_CLI.h"
#include <stdarg.h>
#include <stdio.h>
#include <string.h>

#define MAX_INPUT_LENGTH   64
#define MAX_OUTPUT_LENGTH  512

static Peripheral_Descriptor_t console_port = NULL;
static BaseType_t console_ready = pdFALSE;

BaseType_t Console_IsReady(void)
{
    return console_ready;
}

void Console_Init(void)
{
    /* Nada a fazer aqui por enquanto.
       A UART é aberta dentro da Console_Task. */
}

void Console_Printf(const char *fmt, ...)
{
    if (console_port == NULL) return;

    char buf[256];
    va_list ap;

    va_start(ap, fmt);
    int len = vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);

    if (len > 0)
        FreeRTOS_write(console_port, buf, (size_t)len);
}

void Console_Task(void *argument)
{
    (void)argument;

    char cRxedChar;
    BaseType_t cInputIndex = 0;
    BaseType_t xMoreDataToFollow;

    static char pcInputString[MAX_INPUT_LENGTH];
    static char pcOutputString[MAX_OUTPUT_LENGTH];

    console_port = FreeRTOS_open((const int8_t *)"/LPUART1/", 0);

    uint32_t baud = 115200;
    FreeRTOS_ioctl(console_port, ioctlSET_SPEED, &baud);

    uint32_t parity = UART_PARITY_NONE;
    FreeRTOS_ioctl(console_port, ioctlSET_UART_PARITY_MODE, &parity);

    uint32_t stop = UART_STOPBITS_1;
    FreeRTOS_ioctl(console_port, ioctlSET_UART_NUMBER_OF_STOP_BITS, &stop);

    /* Registra comandos CLI */
    Console_CLI_RegisterCommands();

    Console_Printf("\033c Bem vindo ao EstufaTron %s\r\n>>", tskKERNEL_VERSION_NUMBER);
    console_ready = pdTRUE;

    for (;;)
    {
        FreeRTOS_read(console_port, &cRxedChar, 1);

        if (cRxedChar == '\r')
        {
            Console_Printf("\r\n");

            if (cInputIndex > 0)
            {
                do {
                    xMoreDataToFollow =
                        FreeRTOS_CLIProcessCommand(
                            pcInputString,
                            pcOutputString,
                            MAX_OUTPUT_LENGTH);

                    Console_Printf("%s", pcOutputString);

                } while (xMoreDataToFollow != pdFALSE);

                cInputIndex = 0;
                memset(pcInputString, 0, sizeof(pcInputString));
            }

            Console_Printf(">>");
        }
        else if (cRxedChar == 0x7F || cRxedChar == 0x08)
        {
            if (cInputIndex > 0)
            {
                cInputIndex--;
                Console_Printf("\b \b");
            }
        }
        else if (cRxedChar >= 0x20 && cRxedChar <= 0x7E)
        {
            if (cInputIndex < MAX_INPUT_LENGTH - 1)
            {
                pcInputString[cInputIndex++] = cRxedChar;
                Console_Printf("%c", cRxedChar);
            }
        }
    }
}

