/*
 * console_cli.c
 *
 *  Created on: Dec 17, 2025
 *      Author: Lukinhas
 */

#include "FreeRTOS.h"
#include "FreeRTOS_CLI.h"
#include "task.h"

#include "console/console_cli.h"
#include "control/fan_control.h"
#include "control/lamp_control.h"
#include "services/system_status.h"
#include "services/thermal_control.h"
#include "services/sd_logger.h"
#include "services/cli_stats.h"

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

/* ---- comandos individuais aqui ---- */

static BaseType_t prvTasksCommand(char *buf, size_t len, const char *cmd)
{
    (void)cmd;
    CLI_CopyTaskList(buf, len);
    return pdFALSE;
}

static BaseType_t prvRuntimeCommand(char *buf, size_t len, const char *cmd)
{
    (void)cmd;
    CLI_CopyRuntime(buf, len);
    return pdFALSE;
}
static BaseType_t prvHelpCommand(char *buf, size_t len, const char *cmd)
{
    strcpy(buf,
        "Comandos disponiveis:\r\n"
        " help\r\n"
        " tasks\r\n"
        " runtime\r\n"
        " auto on|off\r\n"
        " fan [on|off|N]\r\n"
        " lamp [on|off|N]\r\n"
        " sd\r\n");
    return pdFALSE;
}

static BaseType_t prvClearCommand(char *buf, size_t len, const char *cmd)
{
    strcpy(buf, "\033c");
    return pdFALSE;
}

static BaseType_t prvFanCommand(char *buf, size_t len, const char *cmd)
{
    BaseType_t l;
    const char *p = FreeRTOS_CLIGetParameter(cmd, 1, &l);

    /* STATUS */
    if (!p)
    {
        snprintf(buf, len,
            "[FAN]\r\nModo: %s\r\nDuty: %u%%\r\n",
            THERM_GetMode() == THERM_MODE_AUTO ? "AUTO" : "MANUAL",
            SYSSTAT_GetFanPct());
        return pdFALSE;
    }

    /* AUTO ativo → bloqueia comandos */
    if (THERM_GetMode() == THERM_MODE_AUTO)
    {
        strcpy(buf, "[FAN] Em modo AUTO (controle termico)\r\n");
        return pdFALSE;
    }

    /* Manual → sai do AUTO */
    THERM_SetMode(THERM_MODE_MANUAL);

    if (strncmp(p, "on", l) == 0)
    {
        FAN_CTRL_SetManual(100);
        strcpy(buf, "[FAN] Ligada (100%)\r\n");
        return pdFALSE;
    }

    if (strncmp(p, "off", l) == 0)
    {
        FAN_CTRL_SetManual(0);
        strcpy(buf, "[FAN] Desligada\r\n");
        return pdFALSE;
    }

    if (isdigit((unsigned char)p[0]))
    {
        int pct = atoi(p);
        if (pct < 0 || pct > 100)
        {
            strcpy(buf, "[FAN] Valor invalido (0..100)\r\n");
            return pdFALSE;
        }

        FAN_CTRL_SetManual(pct);
        snprintf(buf, len, "[FAN] Duty %d%%\r\n", pct);
        return pdFALSE;
    }

    strcpy(buf, "Uso: fan on | off | <0..100>\r\n");
    return pdFALSE;
}

static BaseType_t prvAutoCommand(char *buf, size_t len, const char *cmd)
{
    BaseType_t l;
    const char *p = FreeRTOS_CLIGetParameter(cmd, 1, &l);

    if (!p)
    {
        snprintf(buf, len,
            "[AUTO]\r\nModo: %s\r\n",
            THERM_GetMode() == THERM_MODE_AUTO ? "ATIVO" : "DESATIVADO");
        return pdFALSE;
    }

    if (strncmp(p, "on", l) == 0)
    {
        THERM_SetMode(THERM_MODE_AUTO);
        strcpy(buf, "[AUTO] Controle termico ativado\r\n");
        return pdFALSE;
    }

    if (strncmp(p, "off", l) == 0)
    {
        THERM_SetMode(THERM_MODE_MANUAL);

        // reset total só aqui:
        FAN_CTRL_SetMode(FAN_MODE_MANUAL);
        FAN_CTRL_SetManual(0);
        LAMP_Off();
        SYSSTAT_SetFanPct(0);
        SYSSTAT_SetLampPct(0);

        strcpy(buf, "[AUTO] Controle termico desativado\r\n");
        return pdFALSE;
    }

    strcpy(buf, "Uso: auto on | auto off\r\n");
    return pdFALSE;
}

static BaseType_t prvLampCommand(char *buf, size_t len, const char *cmd)
{
    BaseType_t l;
    const char *p = FreeRTOS_CLIGetParameter(cmd, 1, &l);

    if (!p)
    {
        uint32_t on, off;
        LAMP_GetWindow(&on, &off);

        snprintf(buf, len,
            "[LAMP]\r\nModo: %s\r\nJanela: %lus ON / %lus OFF\r\n",
            THERM_GetMode() == THERM_MODE_AUTO ? "AUTO" :
            LAMP_GetMode() == LAMP_MODE_ON  ? "ON" :
            LAMP_GetMode() == LAMP_MODE_OFF ? "OFF" : "WINDOW",
            on / 1000, off / 1000);
        return pdFALSE;
    }

    if (THERM_GetMode() == THERM_MODE_AUTO)
    {
        strcpy(buf, "[LAMP] Em modo AUTO (controle termico)\r\n");
        return pdFALSE;
    }

    THERM_SetMode(THERM_MODE_MANUAL);

    if (strncmp(p, "on", l) == 0)
    {
        LAMP_On();
        strcpy(buf, "[LAMP] Ligada (100%)\r\n");
        return pdFALSE;
    }

    if (strncmp(p, "off", l) == 0)
    {
        LAMP_Off();
        strcpy(buf, "[LAMP] Desligada\r\n");
        return pdFALSE;
    }

    if (isdigit((unsigned char)p[0]))
    {
        int n = atoi(p);
        if (n < 0 || n > 10)
        {
            strcpy(buf, "[LAMP] Valor invalido (0..10)\r\n");
            return pdFALSE;
        }

        if (n == 0) { LAMP_Off(); }
        else if (n == 10) { LAMP_On(); }
        else { LAMP_SetWindow(n*1000, (10-n)*1000); }

        snprintf(buf, len,
            "[LAMP] Janela %ds ON / %ds OFF\r\n", n, 10-n);
        return pdFALSE;
    }

    strcpy(buf, "Uso: lamp on | off | <0..10>\r\n");
    return pdFALSE;
}

static BaseType_t prvSdCommand(char *buf, size_t len, const char *cmd)
{
    BaseType_t l;
    const char *p = FreeRTOS_CLIGetParameter(cmd, 1, &l);

    if (!p)
    {
        strcpy(buf, "Uso: sd write | sd read\r\n");
        return pdFALSE;
    }

    sd_cmd_t c;

    if (strncmp(p, "write", l) == 0)
        c = SD_CMD_WRITE;
    else if (strncmp(p, "read", l) == 0)
        c = SD_CMD_READ;
    else
    {
        strcpy(buf, "Uso: sd write | sd read\r\n");
        return pdFALSE;
    }

    if (xQueueSend(SD_GetQueue(), &c, 0) == pdPASS)
        strcpy(buf, "[SD] comando enviado\r\n");
    else
        strcpy(buf, "[SD] fila cheia\r\n");

    return pdFALSE;
}
/* ---- registro central ---- */

void Console_CLI_RegisterCommands(void)
{
    static const CLI_Command_Definition_t cmds[] =
    {
        { "help",    "help\r\n",    prvHelpCommand,    0 },
        { "tasks",   "tasks\r\n",   prvTasksCommand,   0 },
        { "runtime", "runtime\r\n", prvRuntimeCommand, 0 },
        { "auto",    "auto\r\n",    prvAutoCommand,   -1 },
        { "fan",     "fan\r\n",     prvFanCommand,    -1 },
        { "lamp",    "lamp\r\n",    prvLampCommand,   -1 },
		{ "sd", "sd read|write\r\n",prvSdCommand, 	  -1 },
        { "clear",    "clear\r\n",  prvClearCommand,   0 },

    };

    for (size_t i = 0; i < sizeof(cmds)/sizeof(cmds[0]); i++)
        FreeRTOS_CLIRegisterCommand(&cmds[i]);
}

