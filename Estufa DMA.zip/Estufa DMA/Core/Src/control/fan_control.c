/*
 * fan_control.c
 *
 *  Created on: Dec 16, 2025
 *      Author: Lukinhas
 */

#include "control/fan_control.h"
#include "drivers/fan_pwm.h"
#include "services/queue_temp.h"
#include "services/system_status.h"
#include "FreeRTOS.h"
#include "task.h"
#include <stdlib.h>

#define FAN_TEMP_ON   32.0f
#define FAN_TEMP_OFF  29.0f
#define FAN_TEMP_MAX  45.0f
#define FAN_MIN_DUTY  70
#define FAN_MAX_DUTY  100
#define FAN_TEMP_FILTER_N  5
#define FAN_DUTY_STEP_MIN 5

static fan_mode_t g_mode = FAN_MODE_MANUAL;
static uint8_t g_manual_pct = 0;
static uint8_t g_current_pct = 0;
static BaseType_t g_fan_active = pdFALSE;
static float temp_hist[FAN_TEMP_FILTER_N];
static uint8_t temp_idx = 0;
static uint8_t temp_cnt = 0;
static float filter_temp(float t);
static uint8_t calc_duty(float t);

void FAN_CTRL_Init(void)
{
    FAN_PWM_Init();
    FAN_SetPct(0);
}

void FAN_CTRL_SetMode(fan_mode_t mode)
{
    g_mode = mode;
}

fan_mode_t FAN_CTRL_GetMode(void)
{
    return g_mode;
}

void FAN_CTRL_SetManual(uint8_t pct)
{
    if (pct > 100) pct = 100;

    g_manual_pct  = pct;
    g_current_pct = pct;   // <<< ESSENCIAL
    FAN_SetPct(pct);

    SYSSTAT_SetFanPct(pct); // <<< mantém status global coerente
}

uint8_t FAN_CTRL_GetManual(void)
{
    return g_manual_pct;
}

static uint8_t calc_duty(float t)
{
    if (t >= FAN_TEMP_MAX)
        return FAN_MAX_DUTY;

    float ratio = (t - FAN_TEMP_ON) /
                  (FAN_TEMP_MAX - FAN_TEMP_ON);

    if (ratio < 0.0f) ratio = 0.0f;

    return FAN_MIN_DUTY +
           (uint8_t)(ratio * (FAN_MAX_DUTY - FAN_MIN_DUTY));
}

void FAN_CTRL_ProcessTemp(float t)
{
    float tf = filter_temp(t);

    if (tf >= FAN_TEMP_ON)
        g_fan_active = pdTRUE;
    else if (tf <= FAN_TEMP_OFF)
        g_fan_active = pdFALSE;

    if (!g_fan_active)
    {
        FAN_SetPct(0);
        g_current_pct = 0;
        SYSSTAT_SetFanPct(0);
        return;

        return;
    }

    uint8_t duty = calc_duty(tf);

    /* clamp anti-jitter */
    if (abs((int)duty - (int)g_current_pct) < FAN_DUTY_STEP_MIN)
        return;

    FAN_SetPct(duty);
    g_current_pct = duty;
    SYSSTAT_SetFanPct(duty);

}

uint8_t FAN_CTRL_GetCurrent(void)
{
    return g_current_pct;
}

static float filter_temp(float t)
{
    temp_hist[temp_idx++] = t;
    if (temp_idx >= FAN_TEMP_FILTER_N)
        temp_idx = 0;

    if (temp_cnt < FAN_TEMP_FILTER_N)
        temp_cnt++;

    float sum = 0.0f;
    for (uint8_t i = 0; i < temp_cnt; i++)
        sum += temp_hist[i];

    return sum / temp_cnt;
}

void FAN_CTRL_Task(void *arg)
{
    (void)arg;
    float temp;

    for (;;)
    {
        if (g_mode == FAN_MODE_AUTO)
        {
        	if (QUEUE_TempPeek(&temp) == pdPASS)
        	{
        	    FAN_CTRL_ProcessTemp(temp);
        	}
        }

        vTaskDelay(pdMS_TO_TICKS(500));
    }

}


