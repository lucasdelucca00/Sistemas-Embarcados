/*
 * lamp_control.c
 *
 *  Created on: Dec 15, 2025
 *      Author: Lukinhas
 */

#include "control/lamp_control.h"
#include "tasks/task_lamp.h"
#include "services/system_status.h"
#include "FreeRTOS.h"
#include "task.h"
#include "gpio.h"

#define LAMP_GPIO_PORT GPIOB
#define LAMP_GPIO_PIN  GPIO_PIN_5

static lamp_mode_t g_mode = LAMP_MODE_OFF;
static uint32_t g_on_ms  = 1000;
static uint32_t g_off_ms = 1000;



void LAMP_Init(void)
{
    HAL_GPIO_WritePin(LAMP_GPIO_PORT, LAMP_GPIO_PIN, GPIO_PIN_RESET);
    g_mode = LAMP_MODE_OFF;
}

void LAMP_HW_On(void)
{
    HAL_GPIO_WritePin(LAMP_GPIO_PORT, LAMP_GPIO_PIN, GPIO_PIN_SET);
}

void LAMP_HW_Off(void)
{
    HAL_GPIO_WritePin(LAMP_GPIO_PORT, LAMP_GPIO_PIN, GPIO_PIN_RESET);
}
void LAMP_On(void)
{
    g_mode = LAMP_MODE_ON;     // <<< ESSENCIAL
    g_on_ms = 1000;
    g_off_ms = 0;

    SYSSTAT_SetLampPct(100);
}

void LAMP_Off(void)
{
    taskENTER_CRITICAL();
    g_mode = LAMP_MODE_OFF;
    g_on_ms = 0;
    g_off_ms = 0;
    taskEXIT_CRITICAL();

    SYSSTAT_SetLampPct(0);
}

lamp_mode_t LAMP_GetMode(void)
{

    return g_mode;
}

uint32_t LAMP_GetOnTime(void)
{
    return g_on_ms;
}

uint32_t LAMP_GetOffTime(void)
{
    return g_off_ms;
}

void LAMP_SetWindow(uint32_t on_ms, uint32_t off_ms)
{
    if (off_ms == 0)
    {
        LAMP_On();
        return;
    }

    taskENTER_CRITICAL();
    g_on_ms  = on_ms;
    g_off_ms = off_ms;
    g_mode   = LAMP_MODE_WINDOW;
    taskEXIT_CRITICAL();

    SYSSTAT_SetLampPct(70); // opcional: status “janela”
}

void LAMP_GetWindow(uint32_t *on_ms, uint32_t *off_ms)
{
    if (!on_ms || !off_ms) return;

    taskENTER_CRITICAL();
    *on_ms  = g_on_ms;
    *off_ms = g_off_ms;
    taskEXIT_CRITICAL();
}

