/*
 * fan_pwm.c
 *
 *  Created on: Dec 16, 2025
 *      Author: Lukinhas
 */

#include "drivers/fan_pwm.h"
#include "tim.h"

void FAN_PWM_Init(void)
{
    FAN_PWM_SetDuty(0);
    HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_4);
}

void FAN_PWM_SetDuty(uint8_t pct)
{
    if (pct > 100) pct = 100;

    uint32_t arr = __HAL_TIM_GET_AUTORELOAD(&htim3);
    uint32_t ccr = (pct * (arr + 1)) / 100;

    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_4, ccr);
}

void FAN_SetPct(uint8_t pct)
{
    if (pct > 100) pct = 100;

    uint32_t arr = __HAL_TIM_GET_AUTORELOAD(&htim3);
    uint32_t ccr = (pct * (arr + 1)) / 100;

    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_4, ccr);
}
