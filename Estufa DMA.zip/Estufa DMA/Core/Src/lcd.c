/*
 * lcd.c
 *
 *  Created on: Dec 14, 2025
 *      Author: Lukinhas
 */

#include "lcd.h"
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include <stdio.h>
#include <string.h>

/* ====== PINOUT (ajuste aqui se mudar) ====== */
#define LCD_RS_GPIO_Port GPIOC
#define LCD_RS_Pin       GPIO_PIN_1

#define LCD_E_GPIO_Port  GPIOC
#define LCD_E_Pin        GPIO_PIN_2

#define LCD_D4_GPIO_Port GPIOC
#define LCD_D4_Pin       GPIO_PIN_3
#define LCD_D5_GPIO_Port GPIOC
#define LCD_D5_Pin       GPIO_PIN_4
#define LCD_D6_GPIO_Port GPIOC
#define LCD_D6_Pin       GPIO_PIN_5
#define LCD_D7_GPIO_Port GPIOC
#define LCD_D7_Pin       GPIO_PIN_6


/* ====== Delays simples e estáveis (us) ======
   Para “só funcionar”, um delay curto em loop é suficiente.
   Se você quiser precisão, depois trocamos para DWT.
*/
static void lcd_delay_us(volatile uint32_t us)
{
    /* Aproximação: depende do clock. Ajuste se necessário. */
    while(us--)
    {
        for (volatile uint32_t i = 0; i < 20; i++) { __NOP(); }
    }
}

static void lcd_pulse_enable(void)
{
    HAL_GPIO_WritePin(LCD_E_GPIO_Port, LCD_E_Pin, GPIO_PIN_SET);
    lcd_delay_us(2);
    HAL_GPIO_WritePin(LCD_E_GPIO_Port, LCD_E_Pin, GPIO_PIN_RESET);
    lcd_delay_us(50);
}

static void lcd_write4bits(uint8_t nibble)
{
    HAL_GPIO_WritePin(LCD_D4_GPIO_Port, LCD_D4_Pin, (nibble & 0x01) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(LCD_D5_GPIO_Port, LCD_D5_Pin, (nibble & 0x02) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(LCD_D6_GPIO_Port, LCD_D6_Pin, (nibble & 0x04) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(LCD_D7_GPIO_Port, LCD_D7_Pin, (nibble & 0x08) ? GPIO_PIN_SET : GPIO_PIN_RESET);

    lcd_pulse_enable();
}

static void lcd_send(uint8_t value, uint8_t rs)
{
    HAL_GPIO_WritePin(LCD_RS_GPIO_Port, LCD_RS_Pin, rs ? GPIO_PIN_SET : GPIO_PIN_RESET);

    /* high nibble */
    lcd_write4bits((value >> 4) & 0x0F);
    /* low nibble */
    lcd_write4bits(value & 0x0F);
}

static void lcd_command(uint8_t cmd)
{
    lcd_send(cmd, 0);

    /* comandos lentos */
    if (cmd == 0x01 || cmd == 0x02)  /* clear, home */
        HAL_Delay(2);
}

static void lcd_data(uint8_t data)
{
    lcd_send(data, 1);
}

void LCD_Init(void)
{
    /* Estados iniciais */
    HAL_GPIO_WritePin(LCD_RS_GPIO_Port, LCD_RS_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(LCD_E_GPIO_Port,  LCD_E_Pin,  GPIO_PIN_RESET);

    HAL_Delay(50); /* >40ms após energizar */

    /* Sequência padrão para entrar em 4 bits */
    lcd_write4bits(0x03);
    HAL_Delay(5);
    lcd_write4bits(0x03);
    lcd_delay_us(200);
    lcd_write4bits(0x03);
    lcd_delay_us(200);

    lcd_write4bits(0x02); /* 4-bit mode */
    lcd_delay_us(200);

    /* Function set: 4-bit, 2 linhas, 5x8 */
    lcd_command(0x28);
    /* Display ON, cursor OFF, blink OFF */
    lcd_command(0x0C);
    /* Clear */
    lcd_command(0x01);
    /* Entry mode: increment, no shift */
    lcd_command(0x06);
}

void LCD_Clear(void)
{
    lcd_command(0x01);
}

void LCD_Home(void)
{
    lcd_command(0x02);
}

void LCD_SetCursor(uint8_t row, uint8_t col)
{
    /* Endereços DDRAM típicos 16x2: 0x00 e 0x40 */
    uint8_t addr = (row == 0) ? 0x00 : 0x40;
    addr += col;
    lcd_command(0x80 | addr);
}

void LCD_WriteChar(char c)
{
    lcd_data((uint8_t)c);
}

void LCD_WriteString(const char *s)
{
    while (*s)
        LCD_WriteChar(*s++);
}

