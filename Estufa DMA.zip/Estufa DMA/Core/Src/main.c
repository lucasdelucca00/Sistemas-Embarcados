/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "dma.h"
#include "app_fatfs.h"
#include "ff.h"
#include "spi.h"
#include "tim.h"
#include "gpio.h"
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "lcd.h"
#include "services/queue_temp.h"
#include "services/system_status.h"
#include <stdarg.h>
#include <stdlib.h>
#include <ctype.h>

#include "control/fan_control.h"
#include "console/console.h"
#include "control/lamp_control.h"
#include "app/app_init.h"
#include "app/app_tasks.h"
#include "task.h"
#define SHELL_ECHO_CMD_DEBUG  0
#define LAMP_STEP_PCT  5

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "FreeRTOS_CLI.h"
#include "FreeRTOS_IO.h"
#include "tasks/task_temp.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
volatile uint32_t counter = 0;
static volatile BaseType_t g_temp_stream_on = pdFALSE;
SemaphoreHandle_t sem = NULL;
TaskHandle_t g_sdTaskHandle = NULL;
volatile BaseType_t g_console_ready = pdFALSE;
//SemaphoreHandle_t sem_rx = NULL;
QueueHandle_t queue_rx;
QueueHandle_t queue_keyb;
SemaphoreHandle_t mutex = NULL;
TimerHandle_t debounce;
extern UART_HandleTypeDef hlpuart1;

#define SD_STATUS_PATH      "0:/STATUS.TXT"
#define SD_HIST_PATH        "0:/HIST.CSV"
#define SD_HIST_OLD_PATH    "0:/HIST_OLD.CSV"
#define SD_HIST_MAX_BYTES   (100U * 1024U)   // 100 KB (ajuste como quiser)


// Se você ainda não tem fan/lamp, deixa 0 por enquanto.
// Depois você liga isso ao seu PWM/atuadores.
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
void MX_FREERTOS_Init(void);

/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
typedef struct led_t_ {
	GPIO_TypeDef 	*led_port;
	uint16_t 		led_pin;
	TickType_t 		led_toggle_time;
}led_t;


void pisca_led(void *param){
	led_t *led = (led_t *)param;
	TickType_t timer;
	while(1){
		timer = xTaskGetTickCount();
		HAL_GPIO_TogglePin(led->led_port, led->led_pin);
		vTaskDelayUntil(&timer,led->led_toggle_time);
	}
}

#if 0
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart){
	BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
	xSemaphoreGiveFromISR(sem, &pxHigherPriorityTaskWoken);
	portYIELD_FROM_ISR(pxHigherPriorityTaskWoken);
}
#endif

volatile uint32_t cnt1 = 0;

volatile uint32_t cnt2 = 0;
void envia_serial_2(void *param){
	char *texto = "Olá mundo da tarefa 2!\n\r";
	uint32_t len = strlen(texto);
	while(1){
		if (xSemaphoreTake(mutex, 100) == pdTRUE){
			if (HAL_UART_Transmit_IT(&hlpuart1, (uint8_t *)texto, len) == HAL_OK){
				xSemaphoreTake(sem, portMAX_DELAY);
				cnt2++;
			}
			xSemaphoreGive(mutex);
		}
		taskYIELD();
	}
}


#if 0
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart){
	BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
	xQueueSendToBackFromISR(queue_rx, huart->pRxBuffPtr, &pxHigherPriorityTaskWoken);
	portYIELD_FROM_ISR(pxHigherPriorityTaskWoken);
}
#endif

void receive_uart(uint8_t *data){
	xQueueReceive(queue_rx, data, portMAX_DELAY);
}


#define MAX_INPUT_LENGTH    64
#define MAX_OUTPUT_LENGTH   512
Peripheral_Descriptor_t console_port;


#if 1
void read_file(FATFS *fs, char *filename){
	uint32_t  p1, p2, s2;
	uint16_t  cnt = 0;
	// Read/Write Buffer
	uint8_t   	read_buffer[512];
	char 		print_buffer[128];
	FIL file;

	if (f_open(&file, (char*)filename, 	FA_READ) == FR_OK)
	{
		FreeRTOS_write(console_port, "\n\r", 2);

		p2 = 0;
		TickType_t start = xTaskGetTickCount();
		p1 = f_size(&file);

		while (p1)
		{
			if (p1 >= sizeof(read_buffer))
			{
			  cnt = sizeof(read_buffer);
			  p1 -= sizeof(read_buffer);
			}
			else
			{
			  cnt = (uint16_t)p1;
			  p1 = 0;
			}
			if (f_read(&file, (char*)read_buffer, cnt, (UINT*)&s2) != FR_OK)
			{
			  break;
			}else
			{
			p2 += s2;
			if (cnt != s2) break;

			read_buffer[cnt]=0;
			//FreeRTOS_write(console_port, read_buffer, cnt);
		 }
		}
		FreeRTOS_write(console_port, "\n\r", 2);

		TickType_t stop = xTaskGetTickCount();
		f_close(&file);

		int len = sprintf(print_buffer, "\n\r%lu bytes read with %lu bytes/sec.\n\r", p2, stop ? (p2 * 1000 / (stop - start)) : 0);
		FreeRTOS_write(console_port, print_buffer, len);
		FreeRTOS_write(console_port, "\n\r", 2);
	}

}

#endif

void vApplicationStackOverflowHook(TaskHandle_t xTask, char *pcTaskName)
{
    (void)xTask; (void)pcTaskName;
    taskDISABLE_INTERRUPTS();
    while(1) { }
}


void echo(void *param){
	uint8_t data;
	uint8_t data_rx;
	HAL_UART_Receive_IT(&hlpuart1, &data, 1);
	while(1){
		receive_uart(&data_rx);
		if (data_rx == '\r'){
			transmite_uart(&data_rx, 1);
			data_rx = '\n';
			transmite_uart(&data_rx, 1);
		}else{
			transmite_uart(&data_rx, 1);
		}
	}
}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin){
	BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
	HAL_NVIC_DisableIRQ(EXTI15_10_IRQn);
	xTimerStartFromISR(debounce, &pxHigherPriorityTaskWoken);
	portYIELD_FROM_ISR(pxHigherPriorityTaskWoken);
}



typedef enum button_codes_t_ {
	BUTTON_1 = 1,
	BUTTON_2,
	BUTTON_3
}button_codes_t;

void debounce_callback( TimerHandle_t xTimer ){
	uint8_t buffer = BUTTON_1;
	xQueueSendToBack(queue_keyb, &buffer, 0);
	HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_SET); // CS desativado (idle high)

  MX_DMA_Init();
  MX_SPI1_Init();
  if (MX_FATFS_Init() != APP_OK) {
    Error_Handler();
  }

  MX_TIM2_Init();
  MX_TIM3_Init();

  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_4);
  __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_4, 0); // fan desligada

  MX_ADC1_Init();
  MX_TIM6_Init();
  /* USER CODE BEGIN 2 */
  HAL_UART_Transmit(&hlpuart1, (uint8_t*)"BOOT OK\r\n", 9, 100);

  APP_Init();  // inicializa módulos

  /* USER CODE END 2 */
  /* Call init function for freertos objects (in cmsis_os2.c) */
  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  mutex = xSemaphoreCreateMutex();
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  sem = xSemaphoreCreateBinary();
  //sem_rx = xSemaphoreCreateBinary();
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  debounce = xTimerCreate("debounce do teclado", 50, pdFALSE, NULL, debounce_callback);
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  queue_rx = xQueueCreate(16, sizeof(uint8_t));
  queue_keyb = xQueueCreate(16, sizeof(char));
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* definition and creation of defaultTask */

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  //static led_t led_verde = {LED_GPIO_Port, LED_Pin, 500};
  //led_t led_azul = {LED_GPIO_Port, LED_Pin, 200};


  /* USER CODE END RTOS_THREADS */
  APP_CreateTasks();
  /* Start scheduler */
  vTaskStartScheduler();

  /* We should never get here as control is now taken by the scheduler */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1_BOOST);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV6;
  RCC_OscInitStruct.PLL.PLLN = 85;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */

/**
  * Enable DMA controller clock
  */

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */

/* USER CODE BEGIN 4 */
extern unsigned int ulHighFrequencyTimerTicks;
/* USER CODE END 4 */

/* USER CODE BEGIN Header_StartDefaultTask */
/**
  * @brief  Function implementing the defaultTask thread.
  * @param  argument: Not used
  * @retval None
  */

/**
  * @brief  Period elapsed callback in non blocking mode
  * @note   This function is called  when TIM20 interrupt took place, inside
  * HAL_TIM_IRQHandler(). It makes a direct call to HAL_IncTick() to increment
  * a global variable "uwTick" used as application time base.
  * @param  htim : TIM handle
  * @retval None
  */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  /* USER CODE BEGIN Callback 0 */
  counter++;
  if (counter >= 1000){
	  counter = 0;
  }
  /* USER CODE END Callback 0 */
  if (htim->Instance == TIM20)
  {
    HAL_IncTick();
  }
  /* USER CODE BEGIN Callback 1 */
  if (htim->Instance == TIM2)
  {
	  ulHighFrequencyTimerTicks++;
  }
  /* USER CODE END Callback 1 */
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
