/*
 * cli_stats.c
 *
 *  Created on: Dec 18, 2025
 *      Author: Lukinhas
 */

#include "services/cli_stats.h"
#include "FreeRTOS.h"
#include "task.h"
#include <string.h>

static char taskBuf[1024];
static char runtimeBuf[1024];

void CLI_CopyTaskList(char *dst, size_t len)
{
    memset(taskBuf, 0, sizeof(taskBuf));
    vTaskList(taskBuf);

    strncpy(dst, taskBuf, len - 1);
    dst[len - 1] = '\0';
}

void CLI_CopyRuntime(char *dst, size_t len)
{
    memset(runtimeBuf, 0, sizeof(runtimeBuf));
    vTaskGetRunTimeStats(runtimeBuf);

    strncpy(dst, runtimeBuf, len - 1);
    dst[len - 1] = '\0';
}


