/*
 * queue_temp.c
 *
 *  Created on: Dec 17, 2025
 *      Author: Lukinhas
 */

#include "services/system_status.h"
#include "services/queue_temp.h"

QueueHandle_t qTemp = NULL;
static float g_last_temp = 0.0f;
static BaseType_t g_valid = pdFALSE;

void QUEUE_TempInit(void)
{
    if (qTemp == NULL)
    {
        qTemp = xQueueCreate(1, sizeof(float));
    }
}

void QUEUE_TempPublish(float tempC)
{

    taskENTER_CRITICAL();
    g_last_temp = tempC;
    g_valid = pdTRUE;
    taskEXIT_CRITICAL();

    if (qTemp)
        xQueueOverwrite(qTemp, &tempC);
}

BaseType_t QUEUE_TempGetLatest(float *out, TickType_t timeout)
{
    if (!qTemp || !out) return pdFAIL;
    return xQueueReceive(qTemp, out, timeout);
}

BaseType_t QUEUE_TempPeek(float *out)
{
    if (!out || !g_valid) return pdFAIL;

    taskENTER_CRITICAL();
    *out = g_last_temp;
    taskEXIT_CRITICAL();
    return pdPASS;
}
