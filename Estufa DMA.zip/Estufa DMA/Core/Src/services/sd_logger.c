/*
 * sd_logger.c
 *
 *  Created on: Dec 18, 2025
 *      Author: Lukinhas
 */

#include "services/sd_logger.h"
#include "services/system_status.h"
#include "ff.h"
#include <stdio.h>
#include <string.h>

#define LOG_FILE "status.txt"

static QueueHandle_t sdQueue;

void SD_LoggerInit(void)
{
    sdQueue = xQueueCreate(4, sizeof(sd_cmd_t));
}

QueueHandle_t SD_GetQueue(void)
{
    return sdQueue;
}

static void sd_write(void)
{
    FATFS fs;
    FIL fil;
    UINT bw;
    system_status_t st;
    char buf[128];

    SYSSTAT_Get(&st);

    if (f_mount(&fs, "", 1) != FR_OK)
        return;

    if (f_open(&fil, LOG_FILE, FA_CREATE_ALWAYS | FA_WRITE) != FR_OK)
        return;

    int n = snprintf(buf, sizeof(buf),
        "Uptime: %lu ms\r\nTemp: %.2f C\r\nFan: %u %%\r\n",
        (unsigned long)st.uptime_ms,
        (double)st.temp_now_c,
        st.fan_pct);

    if (n > 0)
        f_write(&fil, buf, n, &bw);

    f_close(&fil);
}

static void sd_read(void)
{
    FATFS fs;
    FIL fil;
    char line[64];

    if (f_mount(&fs, "", 1) != FR_OK)
        return;

    if (f_open(&fil, LOG_FILE, FA_READ) != FR_OK)
        return;

    while (f_gets(line, sizeof(line), &fil))
    {
        Console_Printf("%s", line);
    }

    f_close(&fil);
}

void SD_Task(void *arg)
{
    (void)arg;
    sd_cmd_t cmd;

    for (;;)
    {
        if (xQueueReceive(sdQueue, &cmd, portMAX_DELAY) == pdTRUE)
        {
            if (cmd == SD_CMD_WRITE)
                sd_write();
            else if (cmd == SD_CMD_READ)
                sd_read();
        }
    }
}
