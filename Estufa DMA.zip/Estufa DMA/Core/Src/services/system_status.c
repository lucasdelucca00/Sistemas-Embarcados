/*
 * system_status.c
 *
 *  Created on: Dec 15, 2025
 *      Author: Lukinhas
 */

#include "services/system_status.h"
#include "FreeRTOS.h"
#include "task.h"
#include <string.h>

static system_status_t g_status;

void SYS_StatusInit(void)
{
    memset(&g_status, 0, sizeof(g_status));
}

void SYSSTAT_Get(system_status_t *out)
{
    if (!out) return;
    taskENTER_CRITICAL();
    *out = g_status;
    taskEXIT_CRITICAL();
}

void SYS_UpdateLm35Temp(float tempC)
{
    taskENTER_CRITICAL();

    g_status.temp_now_c = tempC;

    if (g_status.temp_n < SYS_TEMP_HIST_N)
        g_status.temp_last[g_status.temp_n++] = tempC;
    else
    {
        memmove(&g_status.temp_last[0],
                &g_status.temp_last[1],
                sizeof(float) * (SYS_TEMP_HIST_N - 1));
        g_status.temp_last[SYS_TEMP_HIST_N - 1] = tempC;
    }

    taskEXIT_CRITICAL();
}

void SYSSTAT_SetTemperature(float tempC)
{
    SYS_UpdateLm35Temp(tempC);
}

void SYS_UpdateOutputs(uint8_t fan_pct, uint8_t lamp_pct)
{
    taskENTER_CRITICAL();
    g_status.fan_pct  = fan_pct;
    g_status.lamp_pct = lamp_pct;
    taskEXIT_CRITICAL();
}

void SYSSTAT_SetFanPct(uint8_t pct)
{
    taskENTER_CRITICAL();
    g_status.fan_pct = pct;
    taskEXIT_CRITICAL();
}

void SYSSTAT_SetLampPct(uint8_t pct)
{
    if (pct > 100) pct = 100;

    taskENTER_CRITICAL();
    g_status.lamp_pct = pct;
    taskEXIT_CRITICAL();
}

uint8_t SYSSTAT_GetFanPct(void)
{
    return g_status.fan_pct;
}

uint8_t SYSSTAT_GetLampPct(void)
{
    uint8_t v;
    taskENTER_CRITICAL();
    v = g_status.lamp_pct;
    taskEXIT_CRITICAL();
    return v;
}

