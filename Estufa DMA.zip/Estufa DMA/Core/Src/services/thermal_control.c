/*
 * thermal_control.c
 *
 *  Created on: Dec 18, 2025
 *      Author: Lukinhas
 */

#include "FreeRTOS.h"
#include "task.h"

#include "control/fan_control.h"
#include "control/lamp_control.h"

#include "services/thermal_control.h"
#include "services/queue_temp.h"
#include "services/system_status.h"

/* ============================
 * Tuning (mantém seu espírito)
 * ============================ */

/* Aquecimento forte abaixo disso */
#define T_HEAT_ENTER_FULL     29.0f

/* Quando subir acima disso sai do FULL e vai para janela */
#define T_HEAT_EXIT_FULL      30.0f

/* Volta para FULL com histerese */
#define T_WINDOW_BACK_FULL    28.8f

/* Acima disso começa resfriamento forte */
#define T_WINDOW_TO_COOL      32.0f

/* Resfriamento forte -> suave quando esfriar */
#define T_COOL_STRONG_EXIT    31.0f

/* Resfriamento suave -> aquecimento quando esfriar bem */
#define T_COOL_SOFT_EXIT      29.0f

/* Suave -> forte se voltar a subir muito */
#define T_COOL_SOFT_BACK_STR  33.0f

/* Janela de aquecimento */
#define HEAT_WIN_ON_MS        7000UL
#define HEAT_WIN_OFF_MS       3000UL

/* ============================
 * Estado global (compartilhado)
 * ============================ */

/* Acesso concorrente: CLI mexe nisso e a task lê.
 * Use volatile + critical para transições. */
static volatile thermal_mode_t  g_mode  = THERM_MODE_MANUAL;
static volatile thermal_state_t g_state = THERM_IDLE;

/* helpers para regiões críticas curtas */
static inline void THERM_Lock(void)   { taskENTER_CRITICAL(); }
static inline void THERM_Unlock(void) { taskEXIT_CRITICAL();  }

/* ============================
 * API pública
 * ============================ */

void THERM_Init(void)
{
    THERM_Lock();
    g_mode  = THERM_MODE_MANUAL;
    g_state = THERM_IDLE;
    THERM_Unlock();
}

thermal_state_t THERM_GetState(void)
{
    thermal_state_t s;
    THERM_Lock();
    s = (thermal_state_t)g_state;
    THERM_Unlock();
    return s;
}

thermal_mode_t THERM_GetMode(void)
{
    thermal_mode_t m;
    THERM_Lock();
    m = (thermal_mode_t)g_mode;
    THERM_Unlock();
    return m;
}

/* Quando AUTO desliga (vai para MANUAL), você pediu:
 *  - desabilitar AUTO de verdade
 *  - desligar fan e lamp imediatamente
 * Isso fica aqui (correto).
 *
 * Mas: em MANUAL, fan e lamp devem ser INDEPENDENTES.
 * Então esta função NÃO deve “desligar o outro” quando o usuário mexe manualmente.
 * Ela só atua quando alguém muda o modo AUTO<->MANUAL.
 */
void THERM_SetMode(thermal_mode_t mode)
{
    taskENTER_CRITICAL();
    thermal_mode_t old = g_mode;
    g_mode = mode;

    if (mode == THERM_MODE_AUTO)
    {
        g_state = THERM_IDLE;
        taskEXIT_CRITICAL();
        return;
    }

    // MANUAL: apenas desativa automação.
    // NÃO zera fan/lamp aqui, senão fan manual apaga lamp e vice-versa.
    g_state = THERM_IDLE;
    taskEXIT_CRITICAL();

    // Se quiser, apenas garante que fan está em modo manual (não muda duty)
    FAN_CTRL_SetMode(FAN_MODE_MANUAL);
}

/* ============================
 * Ações por estado (AUTO)
 * ============================ */

static void apply_state(thermal_state_t s)
{
    /* AUTO sempre comanda fan/lamp diretamente */
    FAN_CTRL_SetMode(FAN_MODE_MANUAL);

    switch (s)
    {
        case THERM_HEAT_FULL:
            /* Lamp 100%, fan 0 */
            LAMP_On();
            FAN_CTRL_SetManual(0);
            SYSSTAT_SetFanPct(0);
            SYSSTAT_SetLampPct(100);
            break;

        case THERM_HEAT_WINDOW:
            /* Janela 7s ON / 3s OFF, fan 0
               (Status de “Lamp” como 70% é apenas informativo) */
            LAMP_SetWindow(HEAT_WIN_ON_MS, HEAT_WIN_OFF_MS);
            FAN_CTRL_SetManual(0);
            SYSSTAT_SetFanPct(0);
            SYSSTAT_SetLampPct(70);
            break;

        case THERM_COOL_STRONG:
            /* Fan 100%, lamp 0 */
            LAMP_Off();
            FAN_CTRL_SetManual(100);
            SYSSTAT_SetFanPct(100);
            SYSSTAT_SetLampPct(0);
            break;

        case THERM_COOL_SOFT:
            /* Fan 70%, lamp 0 */
            LAMP_Off();
            FAN_CTRL_SetManual(70);
            SYSSTAT_SetFanPct(70);
            SYSSTAT_SetLampPct(0);
            break;

        case THERM_IDLE:
        default:
            /* Zona neutra: ambos off */
            LAMP_Off();
            FAN_CTRL_SetManual(0);
            SYSSTAT_SetFanPct(0);
            SYSSTAT_SetLampPct(0);
            break;
    }
}

/* ============================
 * Máquina de estados (AUTO)
 * ============================ */

static thermal_state_t compute_next_state(float t, thermal_state_t cur)
{
    switch (cur)
    {
        case THERM_IDLE:
            /*  <29: aquece forte
                29..30: ainda pode ir para FULL dependendo do seu sistema, mas mantemos FULL ao entrar
                30..32: janela
                >32: resfria forte
             */
            if (t < T_HEAT_ENTER_FULL)  return THERM_HEAT_FULL;
            if (t < T_HEAT_EXIT_FULL)   return THERM_HEAT_FULL;    /* entra suave */
            if (t < T_WINDOW_TO_COOL)   return THERM_HEAT_WINDOW;  /* aqui está a janela 7/3 */
            return THERM_COOL_STRONG;

        case THERM_HEAT_FULL:
            if (t >= T_HEAT_EXIT_FULL)  return THERM_HEAT_WINDOW;
            return THERM_HEAT_FULL;

        case THERM_HEAT_WINDOW:
            if (t <= T_WINDOW_BACK_FULL)   return THERM_HEAT_FULL;
            if (t >= T_WINDOW_TO_COOL)     return THERM_COOL_STRONG;
            return THERM_HEAT_WINDOW;

        case THERM_COOL_STRONG:
            if (t <= T_COOL_STRONG_EXIT)   return THERM_COOL_SOFT;
            return THERM_COOL_STRONG;

        case THERM_COOL_SOFT:
            if (t <= T_COOL_SOFT_EXIT)     return THERM_HEAT_FULL;
            if (t >= T_COOL_SOFT_BACK_STR) return THERM_COOL_STRONG;
            return THERM_COOL_SOFT;

        default:
            return THERM_IDLE;
    }
}

/* ============================
 * Task principal
 * ============================ */

void THERM_Task(void *arg)
{
    (void)arg;
    float t = 0.0f;

    for (;;)
    {
        /* Se não está em AUTO, não executa lógica nenhuma */
        if (THERM_GetMode() != THERM_MODE_AUTO)
        {
            vTaskDelay(pdMS_TO_TICKS(200));
            continue;
        }

        /* Pega última temp */
        if (QUEUE_TempGetLatest(&t, pdMS_TO_TICKS(1000)) == pdPASS)
        {
            SYSSTAT_SetTemperature(t);

            thermal_state_t cur = THERM_GetState();
            thermal_state_t next = compute_next_state(t, cur);

            if (next != cur)
            {
                THERM_Lock();
                g_state = next;
                THERM_Unlock();

                apply_state(next);
            }
        }

        vTaskDelay(pdMS_TO_TICKS(500));
    }
}






