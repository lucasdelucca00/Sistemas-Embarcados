/*
 * task_lamp.c
 *
 *  Created on: Dec 17, 2025
 *      Author: Lukinhas
 */

#include "tasks/task_lamp.h"
#include "control/lamp_control.h"
#include "FreeRTOS.h"
#include "task.h"

void LAMP_Task(void *argument)
{
    (void)argument;

    for (;;)
    {
        lamp_mode_t mode = LAMP_GetMode();

        if (mode == LAMP_MODE_ON)
        {
            LAMP_HW_On();
            vTaskDelay(pdMS_TO_TICKS(200));
        }
        else if (mode == LAMP_MODE_OFF)
        {
            LAMP_HW_Off();
            vTaskDelay(pdMS_TO_TICKS(200));
        }
        else // LAMP_MODE_WINDOW
        {
            uint32_t on_ms, off_ms;
            LAMP_GetWindow(&on_ms, &off_ms);

            LAMP_HW_On();
            vTaskDelay(pdMS_TO_TICKS(on_ms));

            LAMP_HW_Off();
            vTaskDelay(pdMS_TO_TICKS(off_ms));
        }
    }
}
