/*
 * task_lcd.c
 *
 *  Created on: Dec 17, 2025
 *  Author: Lukinhas
 */

/*
 * task_lcd.c
 */

#include "tasks/task_lcd.h"

/* Drivers */
#include "lcd.h"

/* RTOS */
#include "FreeRTOS.h"
#include "task.h"

/* Status global */
#include "services/system_status.h"

/* C padrão */
#include <string.h>
#include <stdio.h>

void StartLcdTask(void *argument)
{
    (void)argument;

    system_status_t st;
    float t = 0.0f;

    char line1[17];
    char line2[17];
    char tmp[17];

    LCD_Init();

    memset(line1, ' ', 16);
    memcpy(line1, "Estufa OK", 9);
    line1[16] = '\0';

    LCD_SetCursor(0, 0);
    LCD_WriteString(line1);

    TickType_t lastWake = xTaskGetTickCount();

    for (;;)
    {
        vTaskDelayUntil(&lastWake, pdMS_TO_TICKS(500));

        SYSSTAT_Get(&st);
        t = st.temp_now_c;

        int n = snprintf(tmp, sizeof(tmp), "Temp: %5.2f C", (double)t);
        if (n < 0) n = 0;
        if (n > 16) n = 16;

        memset(line2, ' ', 16);
        memcpy(line2, tmp, (size_t)n);
        line2[16] = '\0';

        LCD_SetCursor(1, 0);
        LCD_WriteString(line2);
    }
}
