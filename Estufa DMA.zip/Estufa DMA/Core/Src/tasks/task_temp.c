/*
 * task_temp.c
 *
 *  Created on: Dec 17, 2025
 *      Author: Lukinhas
 */


/*
 * task_lm35.c
 */

#include "tasks/task_temp.h"

#include "adc.h"
#include "tim.h"

#include "FreeRTOS.h"
#include "task.h"

#include "services/queue_temp.h"
#include "services/system_status.h"

#include <string.h>

#define LM35_ADC_BUF_LEN   64U

static uint16_t adc_buf[LM35_ADC_BUF_LEN];
static volatile float g_lm35_temp_c = 0.0f;
static TaskHandle_t s_lm35TaskHandle = NULL;

/* ===================== Funções internas ===================== */

static float adc_to_temp(uint16_t adc)
{
    const float vref = 3.3f;
    float v = ((float)adc * vref) / 4095.0f;
    return v * 100.0f; // 10mV/°C
}

static void LM35_UpdateFromBuffer(void)
{
    uint32_t sum = 0;
    for (uint32_t i = 0; i < LM35_ADC_BUF_LEN; i++)
        sum += adc_buf[i];

    uint16_t avg = (uint16_t)(sum / LM35_ADC_BUF_LEN);

    float tempC = adc_to_temp(avg);
    g_lm35_temp_c = tempC;

    /* Publica no barramento */
    QUEUE_TempPublish(tempC);

    /* Atualiza status global */
    SYS_UpdateLm35Temp(tempC);
}

/* ===================== API pública ===================== */

float LM35_GetTempC(void)
{
    return g_lm35_temp_c;
}

/* ===================== Callbacks HAL ===================== */

void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc)
{
    if (hadc->Instance == ADC1 && s_lm35TaskHandle != NULL)
    {
        BaseType_t hpw = pdFALSE;
        vTaskNotifyGiveFromISR(s_lm35TaskHandle, &hpw);
        portYIELD_FROM_ISR(hpw);
    }
}

/* ===================== Task ===================== */

void LM35_Task(void *param)
{
    (void)param;

    s_lm35TaskHandle = xTaskGetCurrentTaskHandle();

    memset(adc_buf, 0, sizeof(adc_buf));

    HAL_ADCEx_Calibration_Start(&hadc1, ADC_SINGLE_ENDED);
    HAL_TIM_Base_Start(&htim6);
    HAL_ADC_Start_DMA(&hadc1, (uint32_t*)adc_buf, LM35_ADC_BUF_LEN);

    for (;;)
    {
        ulTaskNotifyTake(pdTRUE, portMAX_DELAY);
        LM35_UpdateFromBuffer();
    }
}


